/* Student Information
 * Chia-Hua Lu              Sabrina Herrero             Connie Chen
 * CL38755                  SH44786                     CMC5837
 * thegoldflute@gmail.com   sabrinaherrero123@gmail.com conniem09@gmail.com
 * 52075                    52105                       52105
 * 
 * Cristian Martinez
 * CJM4686
 * criscubed@gmail.com
 * 52080
 */

#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);
//<cris>
void system_exit_helper (int e_status);
//</cris>

#endif /*userprog/syscall.h*/ 
